/*
STORE "width" with any number
STORE "height" with any number
STORE "area" with zero value

SET "area" withh "width" times "height"
DISPLAY "area"
*/

/*
STORE "status" with "full"
STORE "action" with empty string

SET "status" with "ban tubeless"

IF "status" equals to "hungry"
    SET "action" with "eat"
ELSE IF "status" equals to "full"
    SET "action" with "sleep"
ELSE
    SET "action" with "status invalid"

DISPLAY "action"
*/

/*
STORE "score" with 65

IF "score" less than equals to 70 AND "score" more than equals to 0
    DO "learn more"
ELSE IF "score" more than 70 AND "score" less than equals to 100
    DO "reward myself"
ELSE 
    DO "Invalid score"
*/
